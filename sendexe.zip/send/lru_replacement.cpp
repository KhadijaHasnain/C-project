/**
 * Assignment 5: Page replacement algorithms
 * @file lru_replacement.cpp
 * @author Your Name
 * @brief A class implementing the LRU page replacement algorithm
 * @version 0.1
 */

#include "lru_replacement.h"
#include <climits>

LRUReplacement::LRUReplacement(int num_pages, int num_frames)
    : Replacement(num_pages, num_frames) {
}

LRUReplacement::~LRUReplacement() {
}

void LRUReplacement::touch_page(int page_num) {
    page_table[page_num].frameNumber = numPageFaults;
    numPageFaults++;
}

void LRUReplacement::load_page(int page_num) {
    for (int i = 0; i < page_table.size(); ++i) {
        if (!page_table[i].validBit) {
            page_table[i].validBit = true;
            page_table[i].frameNumber = numPageFaults;
            numPageFaults++;
            return;
        }
    }
}

int LRUReplacement::replace_page(int page_num) {
    int victimPage = -1;
    int minFrameNumber = INT_MAX;

    for (int i = 0; i < page_table.size(); ++i) {
        if (page_table[i].frameNumber < minFrameNumber) {
            minFrameNumber = page_table[i].frameNumber;
            victimPage = i;
        }
    }

    page_table[victimPage].validBit = false;
    page_table[page_num].frameNumber = numPageFaults;
    numPageFaults++;
    return victimPage;
}
