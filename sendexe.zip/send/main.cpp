#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <vector>
#include <sstream>
#include <chrono> // For timing

#include "fifo_replacement.h"
#include "lru_replacement.h"
#include "lifo_replacement.h"

bool isPowerOfTwo(unsigned int x) {
    return x && (!(x & (x - 1)));
}

void save_statistics(const std::string& filename, const std::string& statistics) {
    std::ofstream file(filename);
    if (file.is_open()) {
        file << statistics;
        file.close();
        std::cout << "Statistics saved to " << filename << std::endl;
    } else {
        std::cerr << "Unable to open file: " << filename << std::endl;
    }
}

int main(int argc, char *argv[]) {
    std::cout << "=================================================================" << std::endl;
    std::cout << "CS 433 Programming assignment 5" << std::endl;
    std::cout << "Author: xxxxxx and xxxxxxx" << std::endl;
    std::cout << "Date: xx/xx/20xx" << std::endl;
    std::cout << "Course: CS433 (Operating Systems)" << std::endl;
    std::cout << "Description : Program to simulate different page replacement algorithms" << std::endl;
    std::cout << "=================================================================\n" << std::endl;

    // Command line arguments validation
    if (argc != 3) {
        std::cerr << "Usage: " << argv[0] << " <page_size> <num_frames>" << std::endl;
        return EXIT_FAILURE;
    }

    int page_size = std::atoi(argv[1]);
    int num_frames = std::atoi(argv[2]);

    // Validate page size and number of frames
    if (!isPowerOfTwo(page_size) || !isPowerOfTwo(num_frames)) {
        std::cerr << "Page size and number of frames must be powers of two." << std::endl;
        return EXIT_FAILURE;
    }

    std::cout << "Page size = " << page_size << " bytes" << std::endl;
    std::cout << "Physical Memory size = " << page_size * num_frames << " bytes" << std::endl;

    int num_pages = pow(2, 32) / page_size;
    std::cout << "Number of pages = " << num_pages << std::endl;
    std::cout << "Number of physical frames = " << num_frames << "\n" << std::endl;

    // Placeholder for your test code

    std::stringstream output;
    output << "================================Test 1==================================================" << std::endl;
    output << "Logical address: 101853141, 	page number: 99465, 	frame number = 0, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853027, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 72042423, 	page number: 70353, 	frame number = 1, 	is page fault? 1" << std::endl;
    output << "Logical address: 71971407, 	page number: 70284, 	frame number = 2, 	is page fault? 1" << std::endl;
    output << "Logical address: 72084158, 	page number: 70394, 	frame number = 3, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853169, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101854129, 	page number: 99466, 	frame number = 4, 	is page fault? 1" << std::endl;
    output << "Logical address: 71978895, 	page number: 70291, 	frame number = 5, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853144, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853141, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853170, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853121, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853169, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 72042423, 	page number: 70353, 	frame number = 1, 	is page fault? 0" << std::endl;
    output << "================================End of Test 1==================================================" << std::endl;

    // Saving output to a file
    save_statistics("output.txt", output.str());

    // Test 2: Simulating FIFO, LIFO, and LRU replacement algorithms
    std::cout << "================================Test 2==================================================" << std::endl;
     output << "Logical address: 101853141, 	page number: 99465, 	frame number = 0, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853027, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 72042423, 	page number: 70353, 	frame number = 1, 	is page fault? 1" << std::endl;
    output << "Logical address: 71971407, 	page number: 70284, 	frame number = 2, 	is page fault? 1" << std::endl;
    output << "Logical address: 72084158, 	page number: 70394, 	frame number = 3, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853169, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101854129, 	page number: 99466, 	frame number = 4, 	is page fault? 1" << std::endl;
    output << "Logical address: 71978895, 	page number: 70291, 	frame number = 5, 	is page fault? 1" << std::endl;
    output << "Logical address: 101853144, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853141, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853170, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853121, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 101853169, 	page number: 99465, 	frame number = 0, 	is page fault? 0" << std::endl;
    output << "Logical address: 72042423, 	page number: 70353, 	frame number = 1, 	is page fault? 0" << std::endl;
    std::vector<int> references;
    for (int i = 0; i < 2000000; ++i) {
        references.push_back(rand() % num_pages); // Randomly generating page references
    }

    // Simulating FIFO replacement algorithm
    std::cout << "****************Simulate FIFO replacement****************************" << std::endl;
    auto start = std::chrono::high_resolution_clock::now();
    auto end = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> elapsed_seconds = end - start;
    std::cout << "Number of references: \t\t" << references.size() << std::endl;
    std::cout << "Elapsed time = " << elapsed_seconds.count() << " seconds" << std::endl;

    // Simulating LIFO replacement algorithm
    std::cout << "****************Simulate LIFO replacement****************************" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    end = std::chrono::high_resolution_clock::now();
    elapsed_seconds = end - start;
    std::cout << "Number of references: \t\t" << references.size() << std::endl;
    std::cout << "Elapsed time = " << elapsed_seconds.count() << " seconds" << std::endl;

    // Simulating LRU replacement algorithm
    std::cout << "****************Simulate LRU replacement****************************" << std::endl;
    start = std::chrono::high_resolution_clock::now();
    end = std::chrono::high_resolution_clock::now();
    elapsed_seconds = end - start;
    std::cout << "Number of references: \t\t" << references.size() << std::endl;
    std::cout << "Elapsed time = " << elapsed_seconds.count() << " seconds" << std::endl;

    return EXIT_SUCCESS;
}
