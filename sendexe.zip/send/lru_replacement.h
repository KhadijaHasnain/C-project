/**
 * Assignment 5: Page replacement algorithms
 * @file lru_replacement.h
 * @author Your Name
 * @brief A class implementing the LRU page replacement algorithm
 * @version 0.1
 */

#pragma once

#include "replacement.h"

/**
 * @brief A class to simulate the least recently used (LRU) page replacement algorithm.
 */
class LRUReplacement : public Replacement {
public:
    /**
     * @brief Constructor
     * @param num_pages The total number of pages
     * @param num_frames The number of frames in physical memory
     */
    LRUReplacement(int num_pages, int num_frames);

    /**
     * @brief Destructor
     */
    virtual ~LRUReplacement();

    /**
     * @brief Access a page already in physical memory
     * @param page_num The logical page number
     */
    virtual void touch_page(int page_num);

    /**
     * @brief Access an invalid page, but free frames are available
     * @param page_num The logical page number
     */
    virtual void load_page(int page_num);

    /**
     * @brief Access an invalid page, and there are no free frames
     * Replace the page with the least recently used page
     * @param page_num The logical page number
     * @return The selected victim page number
     */
    virtual int replace_page(int page_num);
};
